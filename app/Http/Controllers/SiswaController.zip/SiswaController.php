<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Siswa;
use App\Models\Presensi;
use App\Models\Kelas; 
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Exports\SiswaExport;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\SiswaImport;
use App\Services\FonnteService; // Pastikan Service ini dipanggil jika ingin digunakan

class SiswaController extends Controller
{
    /**
     * Menampilkan Halaman Master Data Siswa / Kelas (Menggunakan file dashboard sebagai wrapper)
     */
    public function index(Request $request)
    {
        $filterKelasId = $request->query('kelas_id');
        
        // Ambil semua daftar kelas beserta jumlah siswanya
        $daftar_kelas = Kelas::withCount('siswa')->get(); 

        if ($filterKelasId) {
            // KONDISI B: JIKA KELAS SPESIFIK DIKLIK
            $kelasAktif = Kelas::find($filterKelasId);
            $namaKelasAktif = $kelasAktif ? 'Kelas ' . $kelasAktif->nama_kelas : 'Kelas Tidak Ditemukan';

            $semua_siswa = Siswa::where('kelas_id', $filterKelasId)->get();
            $totalSiswa = $semua_siswa->count();

            $riwayat_presensi = Presensi::with('siswa')
                ->whereDate('waktu_masuk', Carbon::today())
                ->whereHas('siswa', function($query) use ($filterKelasId) {
                    $query->where('kelas_id', $filterKelasId);
                })
                ->orderBy('waktu_masuk', 'desc')
                ->get();

            $siswaHadirHariIni = Presensi::whereDate('waktu_masuk', Carbon::today())
                ->where('status', 'Hadir')
                ->whereHas('siswa', function($query) use ($filterKelasId) {
                    $query->where('kelas_id', $filterKelasId);
                })->count();

            $siswaTerlambat = Presensi::whereDate('waktu_masuk', Carbon::today())
                ->where('status', 'Terlambat')
                ->whereHas('siswa', function($query) use ($filterKelasId) {
                    $query->where('kelas_id', $filterKelasId);
                })->count();

        } else {
            // KONDISI A: TAMPILAN DATA SISWA GLOBAL (SELURUH KELAS)
            $namaKelasAktif = "Semua Kelas";
            
            $semua_siswa = Siswa::with('kelas')->get(); // Menggunakan eager loading 'kelas' agar performa lebih cepat
            $totalSiswa = $semua_siswa->count();
            
            $riwayat_presensi = Presensi::with('siswa')
                ->whereDate('waktu_masuk', Carbon::today())
                ->orderBy('waktu_masuk', 'desc')
                ->get();

            $siswaHadirHariIni = Presensi::whereDate('waktu_masuk', Carbon::today())
                ->where('status', 'Hadir')
                ->count();

            $siswaTerlambat = Presensi::whereDate('waktu_masuk', Carbon::today())
                ->where('status', 'Terlambat')
                ->count();
        }

        // Dikembalikan ke file utama: dashboard.blade.php
        return view('dashboard', compact(
            'semua_siswa', 
            'riwayat_presensi', 
            'totalSiswa', 
            'siswaHadirHariIni', 
            'siswaTerlambat',
            'daftar_kelas',
            'filterKelasId',
            'namaKelasAktif'
        ));
    }

    /**
     * Menampilkan Form Tambah Siswa Baru.
     */
    public function tambah(Request $request)
    {
        $kelasTerpilih = $request->query('kelas_id');
        $daftar_kelas = Kelas::all(); 
        
        return view('siswa.tambah', compact('kelasTerpilih', 'daftar_kelas'));
    }

    /**
     * Menyimpan data siswa baru ke database.
     */
    public function simpan(Request $request)
    {
        $request->validate([
            'rfid_code'       => 'required|string|unique:siswas,rfid_code',
            'nisn'            => 'required|string|unique:siswas,nisn',
            'nama_siswa'      => 'required|string|max:255',
            'no_hp_orang_tua' => 'required|string',
            'kelas_id'        => 'required|exists:kelas,id',
        ], [
            'rfid_code.required' => 'UID RFID tidak boleh kosong!',
            'rfid_code.unique'   => 'UID RFID ini sudah terdaftar oleh siswa lain!',
            'nisn.unique'        => 'NISN ini sudah terdaftar!',
            'nama_siswa.required'=> 'Nama siswa tidak boleh kosong!',
        ]);

        $siswa = Siswa::create([
            'rfid_code'       => $request->rfid_code,
            'nisn'            => $request->nisn,
            'nama_siswa'      => $request->nama_siswa,
            'no_hp_orang_tua' => $request->no_hp_orang_tua,
            'kelas_id'        => $request->kelas_id,
        ]);

        if (!empty($siswa->no_hp_orang_tua) && $siswa->no_hp_orang_tua != '-') {
            try {
                $this->kirimNotifikasiPendaftaran($siswa);
            } catch (\Exception $e) {
                return redirect()->route('kelas.index', ['kelas_id' => $request->kelas_id])->with('sukses', 'Siswa berhasil disimpan, namun notifikasi WA gagal dikirim.');
            }
        }

        return redirect()->route('kelas.index', ['kelas_id' => $request->kelas_id])->with('sukses', 'Data siswa baru berhasil disimpan ke dalam sistem!');
    }

    private function kirimNotifikasiPendaftaran($siswa)
    {
        $isiPesan = "Halo Bapak/Ibu Wali Murid, data pendaftaran sekolah ananda *{$siswa->nama_siswa}* dengan NISN *{$siswa->nisn}* telah berhasil diregistrasikan ke dalam Sistem Presensi RFID Sekolah.";
        return $this->kirimNotifikasiWhatsApp($siswa->no_hp_orang_tua, $isiPesan);
    }

    /**
     * Fungsi untuk ekspor excel data siswa per kelas.
     */
    public function exportExcel(Request $request)
    {
        $kelas_id = $request->query('kelas_id');
        
        $nama_file = 'Data_Siswa';
        if ($kelas_id) {
            $kelas = Kelas::find($kelas_id);
            $nama_file .= '_Kelas_' . ($kelas ? $kelas->nama_kelas : $kelas_id);
        } else {
            $nama_file .= '_Semua_Kelas';
        }
        $nama_file .= '_' . date('Y-m-d') . '.xlsx';

        return Excel::download(new SiswaExport($kelas_id), $nama_file);
    }

    /**
     * Fungsi proses impor data excel dari sekolah
     */
    public function importExcel(Request $request)
    {
        $request->validate([
            'file_excel' => 'required|mimes:xlsx,xls,csv|max:2048',
            'kelas_id'   => 'required|exists:kelas,id',
        ]);

        try {
            $kelasId = $request->input('kelas_id');
            Excel::import(new SiswaImport($kelasId), $request->file('file_excel'));
            return redirect()->route('kelas.index', ['kelas_id' => $kelasId])->with('sukses', 'Berhasil mengimpor daftar nama siswa dari berkas Excel sekolah!');
            
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Gagal memproses berkas: ' . $e->getMessage());
        }
    }

    /**
     * Menampilkan Form Edit Data Siswa.
     */
    public function edit($id)
    {
        $siswa = Siswa::findOrFail($id);
        $daftar_kelas = Kelas::all(); 
        
        return view('siswa.edit', compact('siswa', 'daftar_kelas'));
    }

    /**
     * Memproses Perubahan Data Siswa ke Database.
     */
    public function update(Request $request, $id)
    {
        $siswa = Siswa::findOrFail($id);

        $request->validate([
            'rfid_code'       => 'required|string|unique:siswas,rfid_code,' . $siswa->id,
            'nisn'            => 'required|string|unique:siswas,nisn,' . $siswa->id,
            'nama_siswa'      => 'required|string|max:255',
            'no_hp_orang_tua' => 'required|string', 
            'kelas_id'        => 'required|exists:kelas,id',
        ], [
            'rfid_code.required' => 'UID RFID tidak boleh kosong!',
            'rfid_code.unique'   => 'UID RFID ini sudah digunakan oleh siswa lain!',
            'nisn.unique'        => 'NISN ini sudah digunakan oleh siswa lain!',
            'nama_siswa.required'=> 'Nama siswa tidak boleh kosong!',
        ]);

        $siswa->update([
            'rfid_code'       => $request->rfid_code,
            'nisn'            => $request->nisn,
            'nama_siswa'      => $request->nama_siswa,
            'no_hp_orang_tua' => $request->no_hp_orang_tua, 
            'kelas_id'        => $request->kelas_id,
        ]);

        return redirect()->route('kelas.index', ['kelas_id' => $request->kelas_id])->with('sukses', 'Data siswa berhasil diperbarui!');
    }

    /**
     * Menghapus Data Siswa dari Database.
     */
    public function hapus($id)
    {
        $siswa = Siswa::findOrFail($id);
        
        DB::beginTransaction();
        try {
            if ($siswa->rfid_code) {
                Presensi::where('rfid_code', $siswa->rfid_code)->delete();
            }
            
            $siswa->delete();

            DB::commit();
            return redirect()->back()->with('sukses', 'Data siswa beserta riwayat presensinya berhasil dihapus bersih dari database!');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Gagal menghapus data siswa: ' . $e->getMessage());
        }
    }

    /**
     * Menghapus seluruh data siswa berdasarkan kelas_id tertentu.
     */
    public function hapusSemuaMassa(Request $request)
    {
        $kelas_id = $request->input('kelas_id');

        if (!$kelas_id) {
            return redirect()->back()->with('error', 'Gagal memproses tindakan: Parameter ruang kelas tidak valid.');
        }

        DB::beginTransaction();
        try {
            $rfid_siswa_terhapus = Siswa::where('kelas_id', $kelas_id)->pluck('rfid_code')->filter();

            if ($rfid_siswa_terhapus->isNotEmpty()) {
                Presensi::whereIn('rfid_code', $rfid_siswa_terhapus)->delete();
            }

            $jumlahTerhapus = Siswa::where('kelas_id', $kelas_id)->delete();

            if ($jumlahTerhapus > 0) {
                DB::commit();
                return redirect()->route('kelas.index', ['kelas_id' => $kelas_id])->with('sukses', 'Berhasil mengosongkan seluruh data siswa DAN riwayat presensinya di kelas ini!');
            }

            DB::rollBack();
            return redirect()->route('kelas.index', ['kelas_id' => $kelas_id])->with('error', 'Tidak ada data siswa yang bisa dihapus di kelas ini.');

        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->route('kelas.index', ['kelas_id' => $kelas_id])->with('error', 'Terjadi kesalahan sistem saat menghapus data: ' . $e->getMessage());
        }
    }

    /**
     * Integrasi API WhatsApp Gateway (Fonnte)
     */
    private function kirimNotifikasiWhatsApp($nomor_tujuan, $pesan)
    {
        $token = "TOKEN_FONNTE_ANDA_DISINI"; 

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.fonnte.com/send',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 10, 
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array(
                'target'      => $nomor_tujuan,
                'message'     => $pesan,
                'countryCode' => '62',
            ),
            CURLOPT_HTTPHEADER => array(
                "Authorization: $token"
            ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;
    }
}